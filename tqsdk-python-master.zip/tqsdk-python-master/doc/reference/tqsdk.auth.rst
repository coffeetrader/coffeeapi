.. _tqsdk.auth:

tqsdk.TqAuth - 用户认证类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqAuth
    :members:

