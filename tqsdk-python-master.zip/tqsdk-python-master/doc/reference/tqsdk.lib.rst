.. _tqsdk.lib:

tqsdk.lib - 业务工具库
------------------------------------------------------------------


.. _tqsdk.lib.notify:

tqsdk.TqNotify - 收集通知信息工具
==================================================================
.. autoclass:: tqsdk.TqNotify
    :members:


.. _tqsdk.target_pos_task:

tqsdk.TargetPosTask - 目标持仓工具
==================================================================
.. autoclass:: tqsdk.TargetPosTask
    :members:

.. autoclass:: tqsdk.InsertOrderUntilAllTradedTask
    :members:

.. autoclass:: tqsdk.InsertOrderTask
    :members:


.. _tqsdk.lib.target_pos_scheduler:

tqsdk.TargetPosScheduler - 基于时间维度的目标持仓工具
==================================================================
.. autoclass:: tqsdk.TargetPosScheduler
    :members:
