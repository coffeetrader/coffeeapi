.. _tqsdk.sim:

tqsdk.TqSim - 本地模拟交易
------------------------------------------------------------------
.. autoclass:: tqsdk.TqSim
    :members:
    :inherited-members:


.. _tqsdk.sim_stock:

tqsdk.TqSimStock - 本地股票模拟交易
------------------------------------------------------------------
.. autoclass:: tqsdk.TqSimStock
    :members:
    :inherited-members:
