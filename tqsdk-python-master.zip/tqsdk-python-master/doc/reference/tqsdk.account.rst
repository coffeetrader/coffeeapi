.. _tqsdk.account:

tqsdk.TqAccount - 实盘账户类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqAccount
    :members:
    :inherited-members:
