.. _tqsdk_apis:

TqSdk 模块参考
====================================================================

.. toctree::
    :maxdepth: 1

    tqsdk.api.rst
    tqsdk.auth.rst
    tqsdk.account.rst
    tqsdk.tqkq.rst
    tqsdk.tqzq.rst
    tqsdk.tqctp.rst
    tqsdk.sim.rst
    tqsdk.multiaccount.rst
    tqsdk.objs.rst
    tqsdk.lib.rst
    tqsdk.ta.rst
    tqsdk.tafunc.rst
    tqsdk.backtest.rst
    tqsdk.algorithm.rst
    tqsdk.risk_rule.rst
    tqsdk.tools.download.rst
    tqsdk.exceptions.rst
