.. _tqsdk.tools.downloader:

tqsdk.tools.DataDownloader - 数据下载工具
------------------------------------------------------------------
.. autoclass:: tqsdk.tools.DataDownloader
    :members:

