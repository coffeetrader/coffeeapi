.. _tqsdk.tqzq:

tqsdk.TqZq - 众期交易类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqZq
    :members:
    :inherited-members:
