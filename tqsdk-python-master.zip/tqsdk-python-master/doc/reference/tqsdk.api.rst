.. _tqsdk.api:

tqsdk.TqApi - 框架及核心业务
------------------------------------------------------------------
.. autoclass:: tqsdk.TqApi
    :members:

