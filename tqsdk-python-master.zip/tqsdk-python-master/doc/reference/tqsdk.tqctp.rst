.. _tqsdk.tqctp:

tqsdk.TqCtp - 直连 CTP 交易类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqCtp
    :members:
    :inherited-members:
