.. _tqsdk.algorithm:

tqsdk.algorithm - 算法模块
------------------------------------------------------------------


.. _tqsdk.algorithm.twap:

tqsdk.algorithm.twap - Twap 算法
==================================================================
.. automodule:: tqsdk.algorithm.twap
    :members:


.. _tqsdk.algorithm.time_table_generater:

tqsdk.algorithm.time_table_generater - 生成 time_table 辅助函数
==================================================================
.. automodule:: tqsdk.algorithm.time_table_generater
    :members:
