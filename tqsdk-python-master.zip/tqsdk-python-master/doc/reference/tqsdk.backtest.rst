.. _tqsdk.backtest:

tqsdk.TqBacktest - 策略回测
------------------------------------------------------------------
.. autoclass:: tqsdk.TqBacktest
    :members:
