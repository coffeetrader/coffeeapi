.. _tqsdk.tafunc:

tqsdk.tafunc - 序列计算函数
------------------------------------------------------------------
.. automodule:: tqsdk.tafunc
    :members:
    :autosummary: