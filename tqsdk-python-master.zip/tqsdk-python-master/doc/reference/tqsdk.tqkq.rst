.. _tqsdk.tqkq:

tqsdk.TqKq - 快期模拟交易类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqKq
    :members:
    :inherited-members:


.. _tqsdk.tqkq_stock:

tqsdk.TqKqStock - 快期股票模拟交易类
------------------------------------------------------------------
.. autoclass:: tqsdk.TqKqStock
    :members:
    :inherited-members:
