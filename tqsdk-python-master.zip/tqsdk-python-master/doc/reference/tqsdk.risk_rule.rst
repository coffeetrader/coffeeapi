.. _tqsdk.risk_rule:

tqsdk.risk_rule - 风控类模块
------------------------------------------------------------------
.. automodule:: tqsdk.risk_rule
    :members:
