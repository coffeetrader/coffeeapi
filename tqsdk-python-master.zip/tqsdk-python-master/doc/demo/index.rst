.. _demo:

示例程序
====================================================

.. toctree::
    :maxdepth: 2

    base.rst
    option_base.rst
    algorithm.rst
    strategy.rst
    jupyter.rst

