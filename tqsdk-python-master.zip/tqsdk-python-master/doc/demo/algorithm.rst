.. _demo_algorithm:

算法模块示例
====================================================

.. contents:: 目录


.. _demo-algorithm-twap:

twap_table - 时间平均加权算法
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. literalinclude:: ../../tqsdk/demo/algorithm/twap.py
  :language: python


.. _demo-algorithm-vwap:

vwap_table - 交易量平均加权算法
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. literalinclude:: ../../tqsdk/demo/algorithm/vwap.py
  :language: python