.. _dev:

参与TqSdk开发
========================================

.. toctree::
    :maxdepth: 2

    general.rst
    framework.rst
    async_tool.rst
    gui.rst
    backtest.rst
    unittest.rst

