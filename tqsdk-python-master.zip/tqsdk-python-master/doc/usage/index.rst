.. _usage:

使用TqSdk
========================================

.. toctree::
    :maxdepth: 2

    framework.rst
    shinny_account.rst
    mddatas.rst
    kqd_symbol.rst
    ta.rst
    trade.rst
    option_trade.rst
    targetpostask.rst
    backtest.rst
    web_gui.rst
    jupyter.rst
