.. _tq:

天勤终端
=========================================================================
天勤终端是一款基于TqSdk开发的外部GUI，TqSdk并不需要依赖天勤终端即可运行。

.. toctree::
    :maxdepth: 2

    quickstart.rst
    strategybacktest.rst
    strategyrun.rst
    tqreplay.rst


