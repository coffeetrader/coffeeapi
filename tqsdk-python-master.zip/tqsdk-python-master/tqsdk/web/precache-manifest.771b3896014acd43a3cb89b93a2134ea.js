self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9e87212e7997c6a3e6ff",
    "url": "web/css/app.d72d8978.css"
  },
  {
    "revision": "d91a165d9320a5233a6d",
    "url": "web/css/chunk-vendors.1f44729d.css"
  },
  {
    "revision": "82cf43358c1d5de3b328f77464ef3d42",
    "url": "web/d3.min.js"
  },
  {
    "revision": "143146fa24554ae2c5ac0a3982abb952",
    "url": "web/fonts/ionicons.143146fa.woff2"
  },
  {
    "revision": "99ac3308dd8ee14f749f51538d0d5b9e",
    "url": "web/fonts/ionicons.99ac3308.woff"
  },
  {
    "revision": "d535a25a79fb1365ae814b61e88fae71",
    "url": "web/fonts/ionicons.d535a25a.ttf"
  },
  {
    "revision": "a2c4a261a239aa84463dc70e4bac9b9a",
    "url": "web/img/ionicons.a2c4a261.svg"
  },
  {
    "revision": "760d0976095136c746cc2592a5122cce",
    "url": "web/index.html"
  },
  {
    "revision": "9e87212e7997c6a3e6ff",
    "url": "web/js/app.5eb857be.js"
  },
  {
    "revision": "d91a165d9320a5233a6d",
    "url": "web/js/chunk-vendors.fc3d6c6c.js"
  },
  {
    "revision": "260485a0902e994592bfde307cd2874e",
    "url": "web/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "web/robots.txt"
  }
]);